# projet_parrain
Intégration d'une maquette faite sur figma dans le cadre d'un projet parrain, le but étant le score SEO
